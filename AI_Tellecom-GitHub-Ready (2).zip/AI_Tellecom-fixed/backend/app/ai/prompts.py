FAQ_RESPONSES = {
    "internship_domains": "We currently offer AI Engineering, Data Science, Full Stack Development, Python Development, Machine Learning, Cloud Computing, and DevOps internships.",
    "duration": "The available internship durations are 1 month, 3 months, and 6 months.",
    "eligibility": "Students currently pursuing or having completed a degree in engineering, computer science, or related fields are eligible for our internship program.",
    "fees": "Our internship program is currently offered at affordable rates. Please contact our team for detailed fee structure.",
    "certificate": "Yes, you will receive a completion certificate after successfully completing the internship program.",
    "batch_timings": "We offer three batches: Morning (8 AM - 12 PM), Afternoon (12 PM - 4 PM), and Evening (4 PM - 8 PM).",
    "registration": "You can register by calling our helpline or through our website. I can help you register right now!",
    "projects": "You will work on real-time industry projects under the guidance of experienced mentors.",
}

CONFIRMATION_TEMPLATE = """
Please confirm your details:

Name: {name}
College: {college}
Domain: {domain}
Joining Date: {joining_date}
Duration: {duration}
Batch: {batch}
Contact Number: {contact_number}

Would you like to confirm your registration?
"""

TAMIL_CONFIRMATION_TEMPLATE = """
உங்கள் விவரங்களை உறுதிப்படுத்தவும்:

பெயர்: {name}
கல்லூரி: {college}
துறை: {domain}
சேரும் தேதி: {joining_date}
காலம்: {duration}
பேட்ச்: {batch}
தொடர்பு எண்: {contact_number}

உங்கள் பதிவை உறுதிப்படுத்த விரும்புகிறீர்களா?
"""

GREETING_TAMIL = "Vanakkam, VDart Academy ku varavendum. Naangal ungalukku eppadi udhavi seyya mudiyum?"
GREETING_ENGLISH = "Hello, welcome to VDart Academy. I am the virtual internship assistant. How may I help you today?"
